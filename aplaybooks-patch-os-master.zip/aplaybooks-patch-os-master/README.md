# aplaybooks-patch-os
Demo Ansible Playbooks to Patch OS
